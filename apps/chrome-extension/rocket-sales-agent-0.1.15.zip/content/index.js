var C=/^https:\/\/meet\.google\.com\/([a-z]{3}-[a-z]{4}-[a-z]{3})(?:[/?#].*)?$/i;var A={debug:(...e)=>{},warn:(...e)=>{console.warn(...e)},error:(...e)=>{console.error(...e)}};var F="athena-panel-host",M=50,X="panel.suggestions.",l={meetingId:null,history:[],filter:"all",open:!1},p=null,x=null,b=null,g=null;function k(e){return`${X}${e}`}function R(){if(p)return p;let e=document.getElementById(F);if(e&&e.shadowRoot)return p=e.shadowRoot,p;let t=document.createElement("div");return t.id=F,t.style.cssText="all:initial;position:fixed;z-index:2147483647",document.documentElement.appendChild(t),p=t.attachShadow({mode:"closed"}),G(p),p}function G(e){let t=document.createElement("style");t.textContent=`
    :host { all: initial; }
    .btn {
      position: fixed; bottom: 24px; right: 24px;
      background: rgba(17,24,39,0.42);
      backdrop-filter: blur(28px) saturate(160%);
      -webkit-backdrop-filter: blur(28px) saturate(160%);
      color: #F8FAFC;
      border: 1px solid rgba(255,255,255,0.14);
      border-radius: 999px; padding: 10px 14px;
      font: 600 13px Inter, -apple-system, system-ui, sans-serif;
      letter-spacing: 0.2px;
      cursor: pointer;
      box-shadow: 0 12px 40px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.08);
      text-shadow: 0 1px 2px rgba(0,0,0,0.4);
      display: flex; align-items: center; gap: 8px;
      pointer-events: auto;
      transition: background 150ms ease, transform 150ms ease;
    }
    .btn:hover { background: rgba(17,24,39,0.55); }
    .badge {
      background: #34D399; color: #052e1f;
      border-radius: 999px; font-size: 10px;
      padding: 1px 6px; font-weight: 700;
      min-width: 16px; text-align: center;
      text-shadow: none;
    }
    .panel {
      position: fixed; top: 0; right: 0; bottom: 0; width: 340px;
      background: rgba(17,24,39,0.42);
      backdrop-filter: blur(28px) saturate(160%);
      -webkit-backdrop-filter: blur(28px) saturate(160%);
      color: #F8FAFC;
      border-left: 1px solid rgba(255,255,255,0.14);
      box-shadow: -12px 0 40px rgba(0,0,0,0.28), inset 1px 0 0 rgba(255,255,255,0.06);
      text-shadow: 0 1px 2px rgba(0,0,0,0.4);
      transform: translateX(100%); transition: transform 240ms cubic-bezier(0.22,1,0.36,1);
      display: flex; flex-direction: column;
      font: 13px Inter, -apple-system, system-ui, sans-serif;
      pointer-events: auto;
    }
    .panel.open { transform: translateX(0); }
    .panel header {
      padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,0.10);
      display: flex; align-items: center; gap: 8px;
    }
    .panel header h2 { margin: 0; font-size: 14px; font-weight: 600; letter-spacing: 0.2px; }
    .panel header .close {
      margin-left: auto; cursor: pointer; color: rgba(248,250,252,0.78);
      background: none; border: none; font-size: 18px; padding: 2px 6px;
      border-radius: 6px; line-height: 1;
      transition: background 150ms ease;
    }
    .panel header .close:hover { background: rgba(255,255,255,0.10); }
    .filters {
      display: flex; gap: 6px; padding: 10px 14px; flex-wrap: wrap;
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }
    .chip {
      background: transparent; color: rgba(248,250,252,0.72);
      border: 1px solid rgba(255,255,255,0.18);
      border-radius: 999px; padding: 3px 10px;
      font: 600 11px Inter, -apple-system, system-ui, sans-serif;
      letter-spacing: 0.3px;
      cursor: pointer;
      transition: background 150ms ease, color 150ms ease, border-color 150ms ease;
    }
    .chip:hover { background: rgba(255,255,255,0.06); color: #F8FAFC; }
    .chip.active { background: #34D399; color: #052e1f; border-color: #34D399; text-shadow: none; }
    .list { flex: 1; overflow-y: auto; padding: 12px 14px;
      display: flex; flex-direction: column; gap: 10px; }
    .list .empty { color: rgba(248,250,252,0.55); font-size: 12px; padding: 24px 0; text-align: center; }
    .card {
      background: rgba(255,255,255,0.06);
      border: 1px solid rgba(255,255,255,0.10);
      border-radius: 12px; padding: 12px 14px;
      animation: pulse 600ms ease-out;
    }
    .card .meta {
      display: flex; align-items: center; gap: 8px;
      font: 600 11px Inter, -apple-system, system-ui, sans-serif;
      color: #34D399; text-transform: uppercase;
      letter-spacing: 0.6px; margin-bottom: 6px;
    }
    .card .meta .ago {
      color: rgba(248,250,252,0.55); margin-left: auto;
      font-weight: 400; text-transform: none; letter-spacing: 0.2px;
    }
    .card .answer { color: #F8FAFC; margin-bottom: 6px; line-height: 1.5; font-weight: 500; font-size: 16px; }
    .card .followup { color: #F8FAFC; margin-bottom: 4px; line-height: 1.5; font-weight: 500; font-size: 16px; }
    .footer {
      padding: 10px 14px; border-top: 1px solid rgba(255,255,255,0.08);
      font-size: 11px; color: rgba(248,250,252,0.55); text-align: center;
    }
    .footer a { color: #34D399; text-decoration: none; font-weight: 600; }
    .footer a:hover { text-decoration: underline; }
    @keyframes pulse {
      0%   { background: rgba(52,211,153,0.20); }
      100% { background: rgba(255,255,255,0.06); }
    }
    @media (prefers-reduced-motion: reduce) {
      .panel { transition: none !important; }
      .card { animation: none !important; }
    }
  `,e.appendChild(t);let n=document.createElement("button");n.className="btn",n.type="button";let o=document.createElement("span");o.textContent="Rocket",b=document.createElement("span"),b.className="badge",b.textContent="0",n.appendChild(o),n.appendChild(b),n.addEventListener("click",()=>_()),e.appendChild(n),g=document.createElement("div"),g.className="panel";let s=document.createElement("header"),a=document.createElement("h2");a.textContent="Coach prompts";let r=document.createElement("button");r.className="close",r.type="button",r.textContent="\u2715",r.addEventListener("click",()=>_(!1)),s.appendChild(a),s.appendChild(r),g.appendChild(s);let i=document.createElement("div");i.className="filters";let m=[{key:"all",label:"All"},{key:"ask_next",label:"Ask"},{key:"answer",label:"Answer"},{key:"coach",label:"Coach"},{key:"risk",label:"Risk"}];for(let c of m){let u=document.createElement("button");u.type="button",u.className="chip"+(l.filter===c.key?" active":""),u.dataset.filter=c.key,u.textContent=c.label,u.addEventListener("click",()=>V(c.key)),i.appendChild(u)}g.appendChild(i),x=document.createElement("div"),x.className="list",g.appendChild(x);let h=document.createElement("div");h.className="footer";let f=document.createElement("a");f.textContent="Open meeting in Rocket \u2192",f.href="#",f.addEventListener("click",c=>{c.preventDefault(),chrome.runtime.sendMessage({type:"panel.openInAthena"}).catch(()=>{})}),h.appendChild(f),g.appendChild(h),e.appendChild(g)}function V(e){l.filter=e,p&&(p.querySelectorAll(".chip").forEach(t=>{let n=t;n.classList.toggle("active",n.dataset.filter===e)}),T())}function _(e){l.open=e??!l.open,g?.classList.toggle("open",l.open)}function K(e){if(!e)return"";let t=Date.now()-e;return t<1e4?"just now":t<6e4?`${Math.floor(t/1e3)}s ago`:t<36e5?`${Math.floor(t/6e4)}m ago`:`${Math.floor(t/36e5)}h ago`}function Q(e){return e.rationale?.startsWith("[proactive:capture_start]")?"Opener":e.rationale?.startsWith("[proactive:rep_silence]")?"Next question":e.rationale?.startsWith("[proactive:stage_transition]")?"Stage cue":e.type==="ask_next"?"Ask next":e.type==="answer"?"Answer":e.type==="risk"?"Risk":e.type==="coach"?"Coach":"Suggestion"}function Z(e){return!!(e.answerText&&e.answerText.trim().length>0||e.followupText&&e.followupText.trim().length>0)}function T(){if(!x||!b)return;x.replaceChildren();let e=l.history.filter(Z),t=e.filter(n=>l.filter==="all"?!0:n.type===l.filter);if(t.length===0){let n=document.createElement("div");n.className="empty",n.textContent=e.length===0?"No suggestions yet. Start speaking to trigger the coach.":"No suggestions match this filter.",x.appendChild(n)}else for(let n of t){let o=document.createElement("div");o.className="card";let s=document.createElement("div");s.className="meta";let a=document.createElement("span");a.textContent=Q(n);let r=document.createElement("span");if(r.className="ago",r.textContent=K(n.receivedAt),s.appendChild(a),s.appendChild(r),o.appendChild(s),n.answerText){let i=document.createElement("div");i.className="answer",i.textContent=n.answerText,o.appendChild(i)}if(n.followupText){let i=document.createElement("div");i.className="followup",i.textContent=n.followupText,o.appendChild(i)}x.appendChild(o)}b.textContent=String(l.history.length)}async function J(){if(l.meetingId)try{await chrome.storage.local.set({[k(l.meetingId)]:l.history.slice(0,M)})}catch(e){A.warn("[athena-panel] persist failed",e)}}async function ee(e){l.meetingId=e;try{let n=(await chrome.storage.local.get(k(e)))[k(e)];l.history=Array.isArray(n)?n:[]}catch(t){A.warn("[athena-panel] hydrate failed",t),l.history=[]}R(),T()}function D(e){R();let t={...e,receivedAt:Date.now()};l.history=[t,...l.history].slice(0,M),T(),J()}function N(e){l.meetingId===e&&p||ee(e)}var S=null;function L(){let e=C.exec(window.location.href);if(!e||!e[1])return;let t=e[1],n=document.title?.replace(/^Meet\s*[-–]\s*/i,"").trim()||null;if(S===t)return;S=t,N(t);let o={type:"meet.detected",tabId:-1,meetingUrl:`https://meet.google.com/${t}`,meetingId:t,title:n,detectedAt:new Date().toISOString()};chrome.runtime.sendMessage(o)}L();var P=document.querySelector("title");P&&new MutationObserver(()=>L()).observe(P,{childList:!0,subtree:!0});var H=window.location.href;setInterval(()=>{window.location.href!==H&&(H=window.location.href,L())},1e3);window.addEventListener("beforeunload",()=>{let t=C.exec(window.location.href)?.[1]??S;if(!t)return;let n={type:"meet.left",tabId:-1,meetingId:t};chrome.runtime.sendMessage(n)});var O="athena-overlay-root",z="athena-overlay-style",q=2,U=15e3,$={answer:"#34D399",ask_next:"#60A5FA",coach:"#FBBF24",risk:"#F87171"},ne={answer:"Answer",ask_next:"Ask next",coach:"Coach",risk:"Risk"};function oe(){if(document.getElementById(z))return;let e=document.createElement("style");e.id=z,e.textContent=`
    @keyframes athena-card-in {
      from { opacity: 0; transform: translateY(-6px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes athena-card-out {
      from { opacity: 1; transform: scale(1); }
      to   { opacity: 0; transform: scale(0.98); }
    }
    @keyframes athena-progress {
      from { transform: scaleX(1); }
      to   { transform: scaleX(0); }
    }
    @media (prefers-reduced-motion: reduce) {
      .athena-card { animation: athena-card-in 1ms linear !important; }
      .athena-card.athena-exiting { animation: athena-card-out 1ms linear !important; }
      .athena-progress { animation: none !important; transform: scaleX(0) !important; }
    }
  `,document.documentElement.appendChild(e)}function B(){let e=document.getElementById(O);return e||(oe(),e=document.createElement("div"),e.id=O,e.setAttribute("role","status"),e.setAttribute("aria-live","polite"),e.style.cssText=["position:fixed","top:6vh","left:50%","transform:translateX(-50%)","max-height:40vh","max-width:min(560px,60vw)","width:max-content","z-index:2147483646","display:flex","flex-direction:column-reverse","gap:10px","pointer-events:none","font-family:Inter,-apple-system,system-ui,sans-serif"].join(";"),document.documentElement.appendChild(e),e)}function Y(e,t){let n=window.matchMedia("(prefers-reduced-motion: reduce)").matches,o=Array.from(e.children);if(n||o.length===0){e.appendChild(t);return}let s=new Map;for(let a of o)s.set(a,a.getBoundingClientRect());e.appendChild(t);for(let a of o){let r=s.get(a);if(!r)continue;let i=a.getBoundingClientRect(),m=r.top-i.top;Math.abs(m)<1||(a.style.transition="none",a.style.transform=`translateY(${m}px)`,requestAnimationFrame(()=>{a.style.transition="transform 240ms cubic-bezier(0.22,1,0.36,1)",a.style.transform=""}))}}function re(e){let t=B();for(;t.children.length>=q;)t.lastElementChild?.remove();let n=document.createElement("div");n.className="athena-card",n.style.cssText=["background:rgba(17,24,39,0.42)","backdrop-filter:blur(28px) saturate(160%)","-webkit-backdrop-filter:blur(28px) saturate(160%)","color:#F8FAFC","border:1px solid rgba(255,255,255,0.14)","border-radius:16px","padding:16px 18px","box-shadow:0 12px 40px rgba(0,0,0,0.28),inset 0 1px 0 rgba(255,255,255,0.08)","font-size:17px","line-height:1.5","pointer-events:none","animation:athena-card-in 240ms cubic-bezier(0.22,1,0.36,1)","position:relative","overflow:hidden","text-shadow:0 1px 2px rgba(0,0,0,0.4)"].join(";");let o=e.type??"answer",s=$[o]??$.answer,a=ne[o]??"Suggestion",r=document.createElement("div");r.style.cssText="display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:11px;color:rgba(248,250,252,0.72);font-weight:600;letter-spacing:0.4px";let i=document.createElement("span");if(i.textContent=a.toUpperCase(),i.style.cssText=`color:${s};text-transform:uppercase;letter-spacing:0.6px`,r.appendChild(i),typeof e.confidenceScore=="number"){let d=document.createElement("span");d.textContent=`\xB7 ${e.confidenceScore.toFixed(2)}`,d.style.cssText="opacity:0.65;font-weight:500",r.appendChild(d)}let m=document.createElement("span");m.style.cssText="flex:1",r.appendChild(m);let h=!1,f=()=>{h||(h=!0,n.classList.add("athena-exiting"),n.style.animation="athena-card-out 200ms cubic-bezier(0.4,0,0.2,1) forwards",setTimeout(()=>n.remove(),220))},c=document.createElement("button");c.type="button",c.setAttribute("aria-label","Dismiss suggestion"),c.textContent="\u2715",c.style.cssText="pointer-events:auto;cursor:pointer;background:transparent;border:none;color:rgba(248,250,252,0.78);font-size:13px;padding:2px 6px;border-radius:6px;line-height:1;transition:background 150ms ease",c.addEventListener("mouseenter",()=>{c.style.background="rgba(255,255,255,0.10)"}),c.addEventListener("mouseleave",()=>{c.style.background="transparent"}),c.addEventListener("click",f),r.appendChild(c),n.appendChild(r);let u="color:#F8FAFC;font-weight:500;font-size:17px;line-height:1.5;margin-bottom:6px";if(e.answerText){let d=document.createElement("div");d.textContent=e.answerText,d.style.cssText=u,n.appendChild(d)}if(e.followupText){let d=document.createElement("div");d.textContent=e.followupText,d.style.cssText=u,n.appendChild(d)}if(e.sources&&e.sources.length>0){let d=document.createElement("div");d.style.cssText="margin-top:6px;font-size:10px;color:rgba(248,250,252,0.55)",d.textContent=`Source \xB7 ${e.sources.map(W=>W.documentName??"?").join(", ")}`,n.appendChild(d)}let v=document.createElement("div");v.className="athena-progress",v.style.cssText=["position:absolute","left:0","right:0","bottom:0","height:2px",`background:${s}`,"opacity:0.7","transform-origin:left center",`animation:athena-progress ${U}ms linear forwards`].join(";"),n.appendChild(v),Y(t,n),setTimeout(f,U)}var E=null,y=null,w=null;function ae(e,t){let n=B();if(!E){for(;n.children.length>=q;)n.lastElementChild?.remove();let o=document.createElement("div");o.className="athena-card athena-card-streaming",o.style.cssText=["background:rgba(17,24,39,0.42)","backdrop-filter:blur(28px) saturate(160%)","-webkit-backdrop-filter:blur(28px) saturate(160%)","color:#F8FAFC","border:1px solid rgba(255,255,255,0.14)","border-radius:16px","padding:16px 18px","box-shadow:0 12px 40px rgba(0,0,0,0.28),inset 0 1px 0 rgba(255,255,255,0.08)","font-size:17px","line-height:1.5","pointer-events:none","animation:athena-card-in 240ms cubic-bezier(0.22,1,0.36,1)","position:relative","overflow:hidden","text-shadow:0 1px 2px rgba(0,0,0,0.4)"].join(";");let s=document.createElement("div");s.style.cssText="display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:11px;color:rgba(248,250,252,0.72);font-weight:600;letter-spacing:0.4px";let a=document.createElement("span");a.textContent="COACH",a.style.cssText="color:#34D399;text-transform:uppercase;letter-spacing:0.6px",s.appendChild(a);let r=document.createElement("span");r.textContent="typing\u2026",r.style.cssText="opacity:0.55;font-weight:500;font-style:italic",s.appendChild(r),o.appendChild(s);let i="color:#F8FAFC;font-weight:500;font-size:17px;line-height:1.5;margin-bottom:6px;min-height:1.5em";y=document.createElement("div"),y.style.cssText=i,o.appendChild(y),w=document.createElement("div"),w.style.cssText=i,o.appendChild(w),Y(n,o),E=o}y&&(y.textContent=e??""),w&&(w.textContent=t??"")}function ie(){E&&(E.remove(),E=null,y=null,w=null)}chrome.runtime.onMessage.addListener(e=>{if(e?.type!=="panel.toggle"){if(e?.type==="overlay.suggestion.streaming"){try{ae(e.answerText??null,e.followupText??null)}catch(t){console.warn("[rocket-content] streaming render failed",t)}return}if(!(e?.type!=="overlay.suggestion"||!e.suggestion))try{ie(),D(e.suggestion);let t=!!(e.suggestion.answerText||e.suggestion.followupText);console.debug("[rocket-content] overlay.suggestion",{type:e.suggestion.type,hasAnswer:!!e.suggestion.answerText,hasFollowup:!!e.suggestion.followupText,speakable:t}),t&&re(e.suggestion)}catch(t){console.warn("[rocket-content] overlay render failed",t)}}});var I="athena-recording-pill";function se(){let e=document.getElementById(I);if(e)return;e=document.createElement("div"),e.id=I,e.style.cssText=["position:fixed","top:24px","right:24px","z-index:2147483647","background:rgba(17,24,39,0.42)","backdrop-filter:blur(28px) saturate(160%)","-webkit-backdrop-filter:blur(28px) saturate(160%)","color:#F8FAFC","border:1px solid rgba(255,255,255,0.14)","padding:6px 12px 6px 10px","border-radius:999px","font:600 11px Inter,-apple-system,system-ui,sans-serif","letter-spacing:0.4px","box-shadow:0 12px 40px rgba(0,0,0,0.28),inset 0 1px 0 rgba(255,255,255,0.08)","text-shadow:0 1px 2px rgba(0,0,0,0.4)","pointer-events:none","display:flex","align-items:center","gap:8px"].join(";");let t=document.createElement("span");if(t.style.cssText="width:8px;height:8px;border-radius:999px;background:#F87171;box-shadow:0 0 8px rgba(248,113,113,0.7);animation:athena-pulse 1.5s infinite",e.appendChild(t),e.appendChild(document.createTextNode("Rocket recording")),document.documentElement.appendChild(e),!document.getElementById("athena-pill-style")){let n=document.createElement("style");n.id="athena-pill-style",n.textContent="@keyframes athena-pulse { 0%,100% { opacity:1 } 50% { opacity:0.4 } }",document.documentElement.appendChild(n)}}function le(){document.getElementById(I)?.remove()}function j(){chrome.storage.local.get(["capture"]).then(e=>{let t=e.capture??null;t&&!t.closed?se():le()})}j();chrome.storage.onChanged.addListener((e,t)=>{t!=="local"||!e.capture||j()});
