var h=/^https:\/\/meet\.google\.com\/([a-z]{3}-[a-z]{4}-[a-z]{3})(?:[/?#].*)?$/i;var b={debug:(...e)=>{},warn:(...e)=>{console.warn(...e)},error:(...e)=>{console.error(...e)}};var A="athena-panel-host",T=50,P="panel.suggestions.",r={meetingId:null,history:[],filter:"all",open:!1},c=null,p=null,m=null,d=null;function y(e){return`${P}${e}`}function k(){if(c)return c;let e=document.getElementById(A);if(e&&e.shadowRoot)return c=e.shadowRoot,c;let t=document.createElement("div");return t.id=A,t.style.cssText="all:initial;position:fixed;z-index:2147483647",document.documentElement.appendChild(t),c=t.attachShadow({mode:"closed"}),H(c),c}function H(e){let t=document.createElement("style");t.textContent=`
    :host { all: initial; }
    .btn {
      position: fixed; bottom: 24px; right: 24px;
      background: rgba(15,23,42,0.96); color: #f8fafc;
      border: 1px solid rgba(148,163,184,0.3);
      border-radius: 999px; padding: 10px 14px;
      font: 600 13px -apple-system, system-ui, sans-serif;
      cursor: pointer; box-shadow: 0 8px 24px rgba(0,0,0,0.35);
      display: flex; align-items: center; gap: 8px;
      pointer-events: auto;
    }
    .btn:hover { background: rgba(30,41,59,0.96); }
    .badge {
      background: #10b981; color: #052e1f;
      border-radius: 999px; font-size: 10px;
      padding: 1px 6px; font-weight: 700;
      min-width: 16px; text-align: center;
    }
    .panel {
      position: fixed; top: 0; right: 0; bottom: 0; width: 340px;
      background: rgba(15,23,42,0.97); color: #f8fafc;
      border-left: 1px solid rgba(148,163,184,0.18);
      box-shadow: -8px 0 32px rgba(0,0,0,0.35);
      transform: translateX(100%); transition: transform 200ms ease-out;
      display: flex; flex-direction: column;
      font: 13px -apple-system, system-ui, sans-serif;
      pointer-events: auto;
    }
    .panel.open { transform: translateX(0); }
    .panel header {
      padding: 12px 14px; border-bottom: 1px solid rgba(148,163,184,0.18);
      display: flex; align-items: center; gap: 8px;
    }
    .panel header h2 { margin: 0; font-size: 14px; font-weight: 600; }
    .panel header .close {
      margin-left: auto; cursor: pointer; color: #94a3b8;
      background: none; border: none; font-size: 18px; padding: 0;
    }
    .filters { display: flex; gap: 4px; padding: 8px 12px; flex-wrap: wrap;
      border-bottom: 1px solid rgba(148,163,184,0.12); }
    .chip {
      background: transparent; color: #94a3b8;
      border: 1px solid rgba(148,163,184,0.3);
      border-radius: 999px; padding: 3px 8px;
      font-size: 11px; cursor: pointer;
    }
    .chip.active { background: #10b981; color: #052e1f; border-color: #10b981; }
    .list { flex: 1; overflow-y: auto; padding: 10px 12px;
      display: flex; flex-direction: column; gap: 8px; }
    .list .empty { color: #64748b; font-size: 12px; padding: 20px 0; text-align: center; }
    .card {
      background: rgba(30,41,59,0.5);
      border: 1px solid rgba(148,163,184,0.15);
      border-radius: 8px; padding: 10px 12px;
      animation: pulse 600ms ease-out;
    }
    .card .meta {
      display: flex; align-items: center; gap: 6px;
      font-size: 10px; color: #10b981; text-transform: uppercase;
      letter-spacing: 0.5px; font-weight: 600; margin-bottom: 4px;
    }
    .card .meta .ago { color: #64748b; margin-left: auto; font-weight: 400; text-transform: none; }
    .card .answer { color: #f1f5f9; margin-bottom: 4px; line-height: 1.4; }
    .card .followup { color: #cbd5e1; font-style: italic; line-height: 1.4; }
    .footer { padding: 8px 12px; border-top: 1px solid rgba(148,163,184,0.12);
      font-size: 11px; color: #64748b; text-align: center; }
    .footer a { color: #10b981; text-decoration: none; }
    @keyframes pulse {
      0% { background: rgba(16,185,129,0.18); }
      100% { background: rgba(30,41,59,0.5); }
    }
  `,e.appendChild(t);let n=document.createElement("button");n.className="btn",n.type="button";let i=document.createElement("span");i.textContent="Athena",m=document.createElement("span"),m.className="badge",m.textContent="0",n.appendChild(i),n.appendChild(m),n.addEventListener("click",()=>S()),e.appendChild(n),d=document.createElement("div"),d.className="panel";let s=document.createElement("header"),l=document.createElement("h2");l.textContent="Coach prompts";let o=document.createElement("button");o.className="close",o.type="button",o.textContent="\u2715",o.addEventListener("click",()=>S(!1)),s.appendChild(l),s.appendChild(o),d.appendChild(s);let a=document.createElement("div");a.className="filters";let D=[{key:"all",label:"All"},{key:"ask_next",label:"Ask"},{key:"answer",label:"Answer"},{key:"coach",label:"Coach"},{key:"risk",label:"Risk"}];for(let u of D){let g=document.createElement("button");g.type="button",g.className="chip"+(r.filter===u.key?" active":""),g.dataset.filter=u.key,g.textContent=u.label,g.addEventListener("click",()=>O(u.key)),a.appendChild(g)}d.appendChild(a),p=document.createElement("div"),p.className="list",d.appendChild(p);let x=document.createElement("div");x.className="footer";let f=document.createElement("a");f.textContent="Open meeting in Athena \u2192",f.href="#",f.addEventListener("click",u=>{u.preventDefault(),chrome.runtime.sendMessage({type:"panel.openInAthena"}).catch(()=>{})}),x.appendChild(f),d.appendChild(x),e.appendChild(d)}function O(e){r.filter=e,c&&(c.querySelectorAll(".chip").forEach(t=>{let n=t;n.classList.toggle("active",n.dataset.filter===e)}),E())}function S(e){r.open=e??!r.open,d?.classList.toggle("open",r.open)}function z(e){if(!e)return"";let t=Date.now()-e;return t<1e4?"just now":t<6e4?`${Math.floor(t/1e3)}s ago`:t<36e5?`${Math.floor(t/6e4)}m ago`:`${Math.floor(t/36e5)}h ago`}function q(e){return e.rationale?.startsWith("[proactive:capture_start]")?"Opener":e.rationale?.startsWith("[proactive:rep_silence]")?"Next question":e.rationale?.startsWith("[proactive:stage_transition]")?"Stage cue":e.type==="ask_next"?"Ask next":e.type==="answer"?"Answer":e.type==="risk"?"Risk":e.type==="coach"?"Coach":"Suggestion"}function U(e){return!!(e.answerText&&e.answerText.trim().length>0||e.followupText&&e.followupText.trim().length>0)}function E(){if(!p||!m)return;p.replaceChildren();let e=r.history.filter(U),t=e.filter(n=>r.filter==="all"?!0:n.type===r.filter);if(t.length===0){let n=document.createElement("div");n.className="empty",n.textContent=e.length===0?"No suggestions yet. Start speaking to trigger the coach.":"No suggestions match this filter.",p.appendChild(n)}else for(let n of t){let i=document.createElement("div");i.className="card";let s=document.createElement("div");s.className="meta";let l=document.createElement("span");l.textContent=q(n);let o=document.createElement("span");if(o.className="ago",o.textContent=z(n.receivedAt),s.appendChild(l),s.appendChild(o),i.appendChild(s),n.answerText){let a=document.createElement("div");a.className="answer",a.textContent=n.answerText,i.appendChild(a)}if(n.followupText){let a=document.createElement("div");a.className="followup",a.textContent=`\u2192 ${n.followupText}`,i.appendChild(a)}p.appendChild(i)}m.textContent=String(r.history.length)}async function F(){if(r.meetingId)try{await chrome.storage.local.set({[y(r.meetingId)]:r.history.slice(0,T)})}catch(e){b.warn("[athena-panel] persist failed",e)}}async function $(e){r.meetingId=e;try{let n=(await chrome.storage.local.get(y(e)))[y(e)];r.history=Array.isArray(n)?n:[]}catch(t){b.warn("[athena-panel] hydrate failed",t),r.history=[]}k(),E()}function I(e){k();let t={...e,receivedAt:Date.now()};r.history=[t,...r.history].slice(0,T),E(),F()}function M(e){r.meetingId===e&&c||$(e)}var v=null;function C(){let e=h.exec(window.location.href);if(!e||!e[1])return;let t=e[1],n=document.title?.replace(/^Meet\s*[-–]\s*/i,"").trim()||null;if(v===t)return;v=t,M(t);let i={type:"meet.detected",tabId:-1,meetingUrl:`https://meet.google.com/${t}`,meetingId:t,title:n,detectedAt:new Date().toISOString()};chrome.runtime.sendMessage(i)}C();var L=document.querySelector("title");L&&new MutationObserver(()=>C()).observe(L,{childList:!0,subtree:!0});var _=window.location.href;setInterval(()=>{window.location.href!==_&&(_=window.location.href,C())},1e3);window.addEventListener("beforeunload",()=>{let t=h.exec(window.location.href)?.[1]??v;if(!t)return;let n={type:"meet.left",tabId:-1,meetingId:t};chrome.runtime.sendMessage(n)});var N="athena-overlay-root",B=3,V=45e3;function W(){let e=document.getElementById(N);return e||(e=document.createElement("div"),e.id=N,e.style.cssText=["position:fixed","bottom:24px","right:24px","z-index:2147483647","display:flex","flex-direction:column","gap:8px","max-width:360px","font-family:-apple-system,system-ui,sans-serif","pointer-events:none"].join(";"),document.documentElement.appendChild(e),e)}function X(e){let t=W();for(;t.children.length>=B;)t.firstElementChild?.remove();let n=document.createElement("div");n.style.cssText=["background:rgba(15,23,42,0.96)","color:#f8fafc","border:1px solid rgba(148,163,184,0.3)","border-radius:10px","padding:12px 14px","box-shadow:0 8px 24px rgba(0,0,0,0.3)","pointer-events:auto","font-size:13px","line-height:1.4","animation:athena-fade 200ms ease-out"].join(";");let i=document.createElement("div");i.style.cssText="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;font-size:10px;color:#10b981;font-weight:600;text-transform:uppercase;letter-spacing:0.5px";let s=document.createElement("span");s.textContent=e.type==="ask_next"?"Ask next":e.type==="risk"?"Risk":"Suggestion";let l=document.createElement("span");if(l.textContent="\u2715",l.style.cssText="cursor:pointer;color:#64748b;font-size:14px",l.addEventListener("click",()=>n.remove()),i.appendChild(s),i.appendChild(l),n.appendChild(i),e.answerText){let o=document.createElement("div");o.textContent=e.answerText,o.style.cssText="color:#f1f5f9;margin-bottom:6px",n.appendChild(o)}if(e.followupText){let o=document.createElement("div");o.textContent=`\u2192 ${e.followupText}`,o.style.cssText="color:#94a3b8;font-style:italic",n.appendChild(o)}if(e.sources&&e.sources.length>0){let o=document.createElement("div");o.style.cssText="margin-top:6px;font-size:10px;color:#64748b",o.textContent=`Source: ${e.sources.map(a=>a.documentName??"?").join(", ")}`,n.appendChild(o)}t.appendChild(n),setTimeout(()=>n.remove(),V)}chrome.runtime.onMessage.addListener(e=>{if(e?.type!=="panel.toggle"&&!(e?.type!=="overlay.suggestion"||!e.suggestion))try{I(e.suggestion),(e.suggestion.answerText||e.suggestion.followupText)&&X(e.suggestion)}catch(t){console.warn("[athena-content] overlay render failed",t)}});var w="athena-recording-pill";function G(){let e=document.getElementById(w);if(e)return;e=document.createElement("div"),e.id=w,e.style.cssText=["position:fixed","top:12px","right:12px","z-index:2147483647","background:rgba(220,38,38,0.95)","color:#fff","padding:6px 10px","border-radius:999px","font:600 11px -apple-system,system-ui,sans-serif","letter-spacing:0.3px","box-shadow:0 2px 8px rgba(0,0,0,0.3)","pointer-events:none","display:flex","align-items:center","gap:6px"].join(";");let t=document.createElement("span");if(t.style.cssText="width:8px;height:8px;border-radius:999px;background:#fff;animation:athena-pulse 1.5s infinite",e.appendChild(t),e.appendChild(document.createTextNode("Athena recording")),document.documentElement.appendChild(e),!document.getElementById("athena-pill-style")){let n=document.createElement("style");n.id="athena-pill-style",n.textContent="@keyframes athena-pulse { 0%,100% { opacity:1 } 50% { opacity:0.4 } }",document.documentElement.appendChild(n)}}function Y(){document.getElementById(w)?.remove()}function R(){chrome.storage.local.get(["capture"]).then(e=>{let t=e.capture??null;t&&!t.closed?G():Y()})}R();chrome.storage.onChanged.addListener((e,t)=>{t!=="local"||!e.capture||R()});
