var y=/^https:\/\/meet\.google\.com\/([a-z]{3}-[a-z]{4}-[a-z]{3})(?:[/?#].*)?$/i;var w={debug:(...e)=>{},warn:(...e)=>{console.warn(...e)},error:(...e)=>{console.error(...e)}};var T="athena-panel-host",I=50,U="panel.suggestions.",o={meetingId:null,history:[],filter:"all",open:!1},d=null,f=null,h=null,u=null;function v(e){return`${U}${e}`}function L(){if(d)return d;let e=document.getElementById(T);if(e&&e.shadowRoot)return d=e.shadowRoot,d;let t=document.createElement("div");return t.id=T,t.style.cssText="all:initial;position:fixed;z-index:2147483647",document.documentElement.appendChild(t),d=t.attachShadow({mode:"closed"}),$(d),d}function $(e){let t=document.createElement("style");t.textContent=`
    :host { all: initial; }
    .btn {
      position: fixed; bottom: 24px; right: 24px;
      background: rgba(17,24,39,0.42);
      backdrop-filter: blur(28px) saturate(160%);
      -webkit-backdrop-filter: blur(28px) saturate(160%);
      color: #F8FAFC;
      border: 1px solid rgba(255,255,255,0.14);
      border-radius: 999px; padding: 10px 14px;
      font: 600 13px Inter, -apple-system, system-ui, sans-serif;
      letter-spacing: 0.2px;
      cursor: pointer;
      box-shadow: 0 12px 40px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.08);
      text-shadow: 0 1px 2px rgba(0,0,0,0.4);
      display: flex; align-items: center; gap: 8px;
      pointer-events: auto;
      transition: background 150ms ease, transform 150ms ease;
    }
    .btn:hover { background: rgba(17,24,39,0.55); }
    .badge {
      background: #34D399; color: #052e1f;
      border-radius: 999px; font-size: 10px;
      padding: 1px 6px; font-weight: 700;
      min-width: 16px; text-align: center;
      text-shadow: none;
    }
    .panel {
      position: fixed; top: 0; right: 0; bottom: 0; width: 340px;
      background: rgba(17,24,39,0.42);
      backdrop-filter: blur(28px) saturate(160%);
      -webkit-backdrop-filter: blur(28px) saturate(160%);
      color: #F8FAFC;
      border-left: 1px solid rgba(255,255,255,0.14);
      box-shadow: -12px 0 40px rgba(0,0,0,0.28), inset 1px 0 0 rgba(255,255,255,0.06);
      text-shadow: 0 1px 2px rgba(0,0,0,0.4);
      transform: translateX(100%); transition: transform 240ms cubic-bezier(0.22,1,0.36,1);
      display: flex; flex-direction: column;
      font: 13px Inter, -apple-system, system-ui, sans-serif;
      pointer-events: auto;
    }
    .panel.open { transform: translateX(0); }
    .panel header {
      padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,0.10);
      display: flex; align-items: center; gap: 8px;
    }
    .panel header h2 { margin: 0; font-size: 14px; font-weight: 600; letter-spacing: 0.2px; }
    .panel header .close {
      margin-left: auto; cursor: pointer; color: rgba(248,250,252,0.78);
      background: none; border: none; font-size: 18px; padding: 2px 6px;
      border-radius: 6px; line-height: 1;
      transition: background 150ms ease;
    }
    .panel header .close:hover { background: rgba(255,255,255,0.10); }
    .filters {
      display: flex; gap: 6px; padding: 10px 14px; flex-wrap: wrap;
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }
    .chip {
      background: transparent; color: rgba(248,250,252,0.72);
      border: 1px solid rgba(255,255,255,0.18);
      border-radius: 999px; padding: 3px 10px;
      font: 600 11px Inter, -apple-system, system-ui, sans-serif;
      letter-spacing: 0.3px;
      cursor: pointer;
      transition: background 150ms ease, color 150ms ease, border-color 150ms ease;
    }
    .chip:hover { background: rgba(255,255,255,0.06); color: #F8FAFC; }
    .chip.active { background: #34D399; color: #052e1f; border-color: #34D399; text-shadow: none; }
    .list { flex: 1; overflow-y: auto; padding: 12px 14px;
      display: flex; flex-direction: column; gap: 10px; }
    .list .empty { color: rgba(248,250,252,0.55); font-size: 12px; padding: 24px 0; text-align: center; }
    .card {
      background: rgba(255,255,255,0.06);
      border: 1px solid rgba(255,255,255,0.10);
      border-radius: 12px; padding: 12px 14px;
      animation: pulse 600ms ease-out;
    }
    .card .meta {
      display: flex; align-items: center; gap: 8px;
      font: 600 11px Inter, -apple-system, system-ui, sans-serif;
      color: #34D399; text-transform: uppercase;
      letter-spacing: 0.6px; margin-bottom: 6px;
    }
    .card .meta .ago {
      color: rgba(248,250,252,0.55); margin-left: auto;
      font-weight: 400; text-transform: none; letter-spacing: 0.2px;
    }
    .card .answer { color: #F8FAFC; margin-bottom: 4px; line-height: 1.45; font-weight: 500; }
    .card .followup { color: rgba(248,250,252,0.78); font-style: italic; font-size: 12px; line-height: 1.45; }
    .footer {
      padding: 10px 14px; border-top: 1px solid rgba(255,255,255,0.08);
      font-size: 11px; color: rgba(248,250,252,0.55); text-align: center;
    }
    .footer a { color: #34D399; text-decoration: none; font-weight: 600; }
    .footer a:hover { text-decoration: underline; }
    @keyframes pulse {
      0%   { background: rgba(52,211,153,0.20); }
      100% { background: rgba(255,255,255,0.06); }
    }
    @media (prefers-reduced-motion: reduce) {
      .panel { transition: none !important; }
      .card { animation: none !important; }
    }
  `,e.appendChild(t);let n=document.createElement("button");n.className="btn",n.type="button";let l=document.createElement("span");l.textContent="Rocket",h=document.createElement("span"),h.className="badge",h.textContent="0",n.appendChild(l),n.appendChild(h),n.addEventListener("click",()=>S()),e.appendChild(n),u=document.createElement("div"),u.className="panel";let c=document.createElement("header"),g=document.createElement("h2");g.textContent="Coach prompts";let a=document.createElement("button");a.className="close",a.type="button",a.textContent="\u2715",a.addEventListener("click",()=>S(!1)),c.appendChild(g),c.appendChild(a),u.appendChild(c);let i=document.createElement("div");i.className="filters";let b=[{key:"all",label:"All"},{key:"ask_next",label:"Ask"},{key:"answer",label:"Answer"},{key:"coach",label:"Coach"},{key:"risk",label:"Risk"}];for(let r of b){let p=document.createElement("button");p.type="button",p.className="chip"+(o.filter===r.key?" active":""),p.dataset.filter=r.key,p.textContent=r.label,p.addEventListener("click",()=>q(r.key)),i.appendChild(p)}u.appendChild(i),f=document.createElement("div"),f.className="list",u.appendChild(f);let x=document.createElement("div");x.className="footer";let m=document.createElement("a");m.textContent="Open meeting in Rocket \u2192",m.href="#",m.addEventListener("click",r=>{r.preventDefault(),chrome.runtime.sendMessage({type:"panel.openInAthena"}).catch(()=>{})}),x.appendChild(m),u.appendChild(x),e.appendChild(u)}function q(e){o.filter=e,d&&(d.querySelectorAll(".chip").forEach(t=>{let n=t;n.classList.toggle("active",n.dataset.filter===e)}),E())}function S(e){o.open=e??!o.open,u?.classList.toggle("open",o.open)}function B(e){if(!e)return"";let t=Date.now()-e;return t<1e4?"just now":t<6e4?`${Math.floor(t/1e3)}s ago`:t<36e5?`${Math.floor(t/6e4)}m ago`:`${Math.floor(t/36e5)}h ago`}function Y(e){return e.rationale?.startsWith("[proactive:capture_start]")?"Opener":e.rationale?.startsWith("[proactive:rep_silence]")?"Next question":e.rationale?.startsWith("[proactive:stage_transition]")?"Stage cue":e.type==="ask_next"?"Ask next":e.type==="answer"?"Answer":e.type==="risk"?"Risk":e.type==="coach"?"Coach":"Suggestion"}function j(e){return!!(e.answerText&&e.answerText.trim().length>0||e.followupText&&e.followupText.trim().length>0)}function E(){if(!f||!h)return;f.replaceChildren();let e=o.history.filter(j),t=e.filter(n=>o.filter==="all"?!0:n.type===o.filter);if(t.length===0){let n=document.createElement("div");n.className="empty",n.textContent=e.length===0?"No suggestions yet. Start speaking to trigger the coach.":"No suggestions match this filter.",f.appendChild(n)}else for(let n of t){let l=document.createElement("div");l.className="card";let c=document.createElement("div");c.className="meta";let g=document.createElement("span");g.textContent=Y(n);let a=document.createElement("span");if(a.className="ago",a.textContent=B(n.receivedAt),c.appendChild(g),c.appendChild(a),l.appendChild(c),n.answerText){let i=document.createElement("div");i.className="answer",i.textContent=n.answerText,l.appendChild(i)}if(n.followupText){let i=document.createElement("div");i.className="followup",i.textContent=`\u2192 ${n.followupText}`,l.appendChild(i)}f.appendChild(l)}h.textContent=String(o.history.length)}async function W(){if(o.meetingId)try{await chrome.storage.local.set({[v(o.meetingId)]:o.history.slice(0,I)})}catch(e){w.warn("[athena-panel] persist failed",e)}}async function X(e){o.meetingId=e;try{let n=(await chrome.storage.local.get(v(e)))[v(e)];o.history=Array.isArray(n)?n:[]}catch(t){w.warn("[athena-panel] hydrate failed",t),o.history=[]}L(),E()}function _(e){L();let t={...e,receivedAt:Date.now()};o.history=[t,...o.history].slice(0,I),E(),W()}function R(e){o.meetingId===e&&d||X(e)}var C=null;function k(){let e=y.exec(window.location.href);if(!e||!e[1])return;let t=e[1],n=document.title?.replace(/^Meet\s*[-–]\s*/i,"").trim()||null;if(C===t)return;C=t,R(t);let l={type:"meet.detected",tabId:-1,meetingUrl:`https://meet.google.com/${t}`,meetingId:t,title:n,detectedAt:new Date().toISOString()};chrome.runtime.sendMessage(l)}k();var F=document.querySelector("title");F&&new MutationObserver(()=>k()).observe(F,{childList:!0,subtree:!0});var M=window.location.href;setInterval(()=>{window.location.href!==M&&(M=window.location.href,k())},1e3);window.addEventListener("beforeunload",()=>{let t=y.exec(window.location.href)?.[1]??C;if(!t)return;let n={type:"meet.left",tabId:-1,meetingId:t};chrome.runtime.sendMessage(n)});var D="athena-overlay-root",N="athena-overlay-style",V=2,P=15e3,O={answer:"#34D399",ask_next:"#60A5FA",coach:"#FBBF24",risk:"#F87171"},K={answer:"Answer",ask_next:"Ask next",coach:"Coach",risk:"Risk"};function Q(){if(document.getElementById(N))return;let e=document.createElement("style");e.id=N,e.textContent=`
    @keyframes athena-card-in {
      from { opacity: 0; transform: translateY(-6px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes athena-card-out {
      from { opacity: 1; transform: scale(1); }
      to   { opacity: 0; transform: scale(0.98); }
    }
    @keyframes athena-progress {
      from { transform: scaleX(1); }
      to   { transform: scaleX(0); }
    }
    @media (prefers-reduced-motion: reduce) {
      .athena-card { animation: athena-card-in 1ms linear !important; }
      .athena-card.athena-exiting { animation: athena-card-out 1ms linear !important; }
      .athena-progress { animation: none !important; transform: scaleX(0) !important; }
    }
  `,document.documentElement.appendChild(e)}function Z(){let e=document.getElementById(D);return e||(Q(),e=document.createElement("div"),e.id=D,e.setAttribute("role","status"),e.setAttribute("aria-live","polite"),e.style.cssText=["position:fixed","top:24px","left:50%","transform:translateX(-50%)","max-height:15vh","max-width:min(560px,60vw)","width:max-content","z-index:2147483646","display:flex","flex-direction:column-reverse","gap:10px","pointer-events:none","font-family:Inter,-apple-system,system-ui,sans-serif"].join(";"),document.documentElement.appendChild(e),e)}function J(e){let t=Z();for(;t.children.length>=V;)t.lastElementChild?.remove();let n=document.createElement("div");n.className="athena-card",n.style.cssText=["background:rgba(17,24,39,0.42)","backdrop-filter:blur(28px) saturate(160%)","-webkit-backdrop-filter:blur(28px) saturate(160%)","color:#F8FAFC","border:1px solid rgba(255,255,255,0.14)","border-radius:16px","padding:14px 16px","box-shadow:0 12px 40px rgba(0,0,0,0.28),inset 0 1px 0 rgba(255,255,255,0.08)","font-size:14px","line-height:1.45","pointer-events:none","animation:athena-card-in 240ms cubic-bezier(0.22,1,0.36,1)","position:relative","overflow:hidden","text-shadow:0 1px 2px rgba(0,0,0,0.4)"].join(";");let l=e.type??"answer",c=O[l]??O.answer,g=K[l]??"Suggestion",a=document.createElement("div");a.style.cssText="display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:11px;color:rgba(248,250,252,0.72);font-weight:600;letter-spacing:0.4px";let i=document.createElement("span");if(i.textContent=g.toUpperCase(),i.style.cssText=`color:${c};text-transform:uppercase;letter-spacing:0.6px`,a.appendChild(i),typeof e.confidenceScore=="number"){let s=document.createElement("span");s.textContent=`\xB7 ${e.confidenceScore.toFixed(2)}`,s.style.cssText="opacity:0.65;font-weight:500",a.appendChild(s)}let b=document.createElement("span");b.style.cssText="flex:1",a.appendChild(b);let x=!1,m=()=>{x||(x=!0,n.classList.add("athena-exiting"),n.style.animation="athena-card-out 200ms cubic-bezier(0.4,0,0.2,1) forwards",setTimeout(()=>n.remove(),220))},r=document.createElement("button");if(r.type="button",r.setAttribute("aria-label","Dismiss suggestion"),r.textContent="\u2715",r.style.cssText="pointer-events:auto;cursor:pointer;background:transparent;border:none;color:rgba(248,250,252,0.78);font-size:13px;padding:2px 6px;border-radius:6px;line-height:1;transition:background 150ms ease",r.addEventListener("mouseenter",()=>{r.style.background="rgba(255,255,255,0.10)"}),r.addEventListener("mouseleave",()=>{r.style.background="transparent"}),r.addEventListener("click",m),a.appendChild(r),n.appendChild(a),e.answerText){let s=document.createElement("div");s.textContent=e.answerText,s.style.cssText="color:#F8FAFC;font-weight:500;margin-bottom:6px",n.appendChild(s)}if(e.followupText){let s=document.createElement("div");s.textContent=`\u2192 Ask next: ${e.followupText}`,s.style.cssText="color:rgba(248,250,252,0.78);font-style:italic;font-size:12px;margin-bottom:4px",n.appendChild(s)}if(e.sources&&e.sources.length>0){let s=document.createElement("div");s.style.cssText="margin-top:6px;font-size:10px;color:rgba(248,250,252,0.55)",s.textContent=`Source \xB7 ${e.sources.map(z=>z.documentName??"?").join(", ")}`,n.appendChild(s)}let p=document.createElement("div");p.className="athena-progress",p.style.cssText=["position:absolute","left:0","right:0","bottom:0","height:2px",`background:${c}`,"opacity:0.7","transform-origin:left center",`animation:athena-progress ${P}ms linear forwards`].join(";"),n.appendChild(p),t.appendChild(n),setTimeout(m,P)}chrome.runtime.onMessage.addListener(e=>{if(e?.type!=="panel.toggle"&&!(e?.type!=="overlay.suggestion"||!e.suggestion))try{_(e.suggestion);let t=!!(e.suggestion.answerText||e.suggestion.followupText);console.debug("[rocket-content] overlay.suggestion",{type:e.suggestion.type,hasAnswer:!!e.suggestion.answerText,hasFollowup:!!e.suggestion.followupText,speakable:t}),t&&J(e.suggestion)}catch(t){console.warn("[rocket-content] overlay render failed",t)}});var A="athena-recording-pill";function ee(){let e=document.getElementById(A);if(e)return;e=document.createElement("div"),e.id=A,e.style.cssText=["position:fixed","top:24px","right:24px","z-index:2147483647","background:rgba(17,24,39,0.42)","backdrop-filter:blur(28px) saturate(160%)","-webkit-backdrop-filter:blur(28px) saturate(160%)","color:#F8FAFC","border:1px solid rgba(255,255,255,0.14)","padding:6px 12px 6px 10px","border-radius:999px","font:600 11px Inter,-apple-system,system-ui,sans-serif","letter-spacing:0.4px","box-shadow:0 12px 40px rgba(0,0,0,0.28),inset 0 1px 0 rgba(255,255,255,0.08)","text-shadow:0 1px 2px rgba(0,0,0,0.4)","pointer-events:none","display:flex","align-items:center","gap:8px"].join(";");let t=document.createElement("span");if(t.style.cssText="width:8px;height:8px;border-radius:999px;background:#F87171;box-shadow:0 0 8px rgba(248,113,113,0.7);animation:athena-pulse 1.5s infinite",e.appendChild(t),e.appendChild(document.createTextNode("Rocket recording")),document.documentElement.appendChild(e),!document.getElementById("athena-pill-style")){let n=document.createElement("style");n.id="athena-pill-style",n.textContent="@keyframes athena-pulse { 0%,100% { opacity:1 } 50% { opacity:0.4 } }",document.documentElement.appendChild(n)}}function te(){document.getElementById(A)?.remove()}function H(){chrome.storage.local.get(["capture"]).then(e=>{let t=e.capture??null;t&&!t.closed?ee():te()})}H();chrome.storage.onChanged.addListener((e,t)=>{t!=="local"||!e.capture||H()});
