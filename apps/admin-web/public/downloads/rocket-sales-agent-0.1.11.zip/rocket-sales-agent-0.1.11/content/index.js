var E=/^https:\/\/meet\.google\.com\/([a-z]{3}-[a-z]{4}-[a-z]{3})(?:[/?#].*)?$/i;var C={debug:(...e)=>{},warn:(...e)=>{console.warn(...e)},error:(...e)=>{console.error(...e)}};var L="athena-panel-host",F=50,Y="panel.suggestions.",a={meetingId:null,history:[],filter:"all",open:!1},u=null,f=null,h=null,g=null;function A(e){return`${Y}${e}`}function M(){if(u)return u;let e=document.getElementById(L);if(e&&e.shadowRoot)return u=e.shadowRoot,u;let t=document.createElement("div");return t.id=L,t.style.cssText="all:initial;position:fixed;z-index:2147483647",document.documentElement.appendChild(t),u=t.attachShadow({mode:"closed"}),W(u),u}function W(e){let t=document.createElement("style");t.textContent=`
    :host { all: initial; }
    .btn {
      position: fixed; bottom: 24px; right: 24px;
      background: rgba(17,24,39,0.42);
      backdrop-filter: blur(28px) saturate(160%);
      -webkit-backdrop-filter: blur(28px) saturate(160%);
      color: #F8FAFC;
      border: 1px solid rgba(255,255,255,0.14);
      border-radius: 999px; padding: 10px 14px;
      font: 600 13px Inter, -apple-system, system-ui, sans-serif;
      letter-spacing: 0.2px;
      cursor: pointer;
      box-shadow: 0 12px 40px rgba(0,0,0,0.28), inset 0 1px 0 rgba(255,255,255,0.08);
      text-shadow: 0 1px 2px rgba(0,0,0,0.4);
      display: flex; align-items: center; gap: 8px;
      pointer-events: auto;
      transition: background 150ms ease, transform 150ms ease;
    }
    .btn:hover { background: rgba(17,24,39,0.55); }
    .badge {
      background: #34D399; color: #052e1f;
      border-radius: 999px; font-size: 10px;
      padding: 1px 6px; font-weight: 700;
      min-width: 16px; text-align: center;
      text-shadow: none;
    }
    .panel {
      position: fixed; top: 0; right: 0; bottom: 0; width: 340px;
      background: rgba(17,24,39,0.42);
      backdrop-filter: blur(28px) saturate(160%);
      -webkit-backdrop-filter: blur(28px) saturate(160%);
      color: #F8FAFC;
      border-left: 1px solid rgba(255,255,255,0.14);
      box-shadow: -12px 0 40px rgba(0,0,0,0.28), inset 1px 0 0 rgba(255,255,255,0.06);
      text-shadow: 0 1px 2px rgba(0,0,0,0.4);
      transform: translateX(100%); transition: transform 240ms cubic-bezier(0.22,1,0.36,1);
      display: flex; flex-direction: column;
      font: 13px Inter, -apple-system, system-ui, sans-serif;
      pointer-events: auto;
    }
    .panel.open { transform: translateX(0); }
    .panel header {
      padding: 14px 16px; border-bottom: 1px solid rgba(255,255,255,0.10);
      display: flex; align-items: center; gap: 8px;
    }
    .panel header h2 { margin: 0; font-size: 14px; font-weight: 600; letter-spacing: 0.2px; }
    .panel header .close {
      margin-left: auto; cursor: pointer; color: rgba(248,250,252,0.78);
      background: none; border: none; font-size: 18px; padding: 2px 6px;
      border-radius: 6px; line-height: 1;
      transition: background 150ms ease;
    }
    .panel header .close:hover { background: rgba(255,255,255,0.10); }
    .filters {
      display: flex; gap: 6px; padding: 10px 14px; flex-wrap: wrap;
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }
    .chip {
      background: transparent; color: rgba(248,250,252,0.72);
      border: 1px solid rgba(255,255,255,0.18);
      border-radius: 999px; padding: 3px 10px;
      font: 600 11px Inter, -apple-system, system-ui, sans-serif;
      letter-spacing: 0.3px;
      cursor: pointer;
      transition: background 150ms ease, color 150ms ease, border-color 150ms ease;
    }
    .chip:hover { background: rgba(255,255,255,0.06); color: #F8FAFC; }
    .chip.active { background: #34D399; color: #052e1f; border-color: #34D399; text-shadow: none; }
    .list { flex: 1; overflow-y: auto; padding: 12px 14px;
      display: flex; flex-direction: column; gap: 10px; }
    .list .empty { color: rgba(248,250,252,0.55); font-size: 12px; padding: 24px 0; text-align: center; }
    .card {
      background: rgba(255,255,255,0.06);
      border: 1px solid rgba(255,255,255,0.10);
      border-radius: 12px; padding: 12px 14px;
      animation: pulse 600ms ease-out;
    }
    .card .meta {
      display: flex; align-items: center; gap: 8px;
      font: 600 11px Inter, -apple-system, system-ui, sans-serif;
      color: #34D399; text-transform: uppercase;
      letter-spacing: 0.6px; margin-bottom: 6px;
    }
    .card .meta .ago {
      color: rgba(248,250,252,0.55); margin-left: auto;
      font-weight: 400; text-transform: none; letter-spacing: 0.2px;
    }
    .card .answer { color: #F8FAFC; margin-bottom: 4px; line-height: 1.45; font-weight: 500; }
    .card .followup { color: rgba(248,250,252,0.78); font-style: italic; font-size: 12px; line-height: 1.45; }
    .footer {
      padding: 10px 14px; border-top: 1px solid rgba(255,255,255,0.08);
      font-size: 11px; color: rgba(248,250,252,0.55); text-align: center;
    }
    .footer a { color: #34D399; text-decoration: none; font-weight: 600; }
    .footer a:hover { text-decoration: underline; }
    @keyframes pulse {
      0%   { background: rgba(52,211,153,0.20); }
      100% { background: rgba(255,255,255,0.06); }
    }
    @media (prefers-reduced-motion: reduce) {
      .panel { transition: none !important; }
      .card { animation: none !important; }
    }
  `,e.appendChild(t);let n=document.createElement("button");n.className="btn",n.type="button";let r=document.createElement("span");r.textContent="Rocket",h=document.createElement("span"),h.className="badge",h.textContent="0",n.appendChild(r),n.appendChild(h),n.addEventListener("click",()=>_()),e.appendChild(n),g=document.createElement("div"),g.className="panel";let s=document.createElement("header"),p=document.createElement("h2");p.textContent="Coach prompts";let o=document.createElement("button");o.className="close",o.type="button",o.textContent="\u2715",o.addEventListener("click",()=>_(!1)),s.appendChild(p),s.appendChild(o),g.appendChild(s);let l=document.createElement("div");l.className="filters";let v=[{key:"all",label:"All"},{key:"ask_next",label:"Ask"},{key:"answer",label:"Answer"},{key:"coach",label:"Coach"},{key:"risk",label:"Risk"}];for(let i of v){let d=document.createElement("button");d.type="button",d.className="chip"+(a.filter===i.key?" active":""),d.dataset.filter=i.key,d.textContent=i.label,d.addEventListener("click",()=>X(i.key)),l.appendChild(d)}g.appendChild(l),f=document.createElement("div"),f.className="list",g.appendChild(f);let x=document.createElement("div");x.className="footer";let m=document.createElement("a");m.textContent="Open meeting in Rocket \u2192",m.href="#",m.addEventListener("click",i=>{i.preventDefault(),chrome.runtime.sendMessage({type:"panel.openInAthena"}).catch(()=>{})}),x.appendChild(m),g.appendChild(x),e.appendChild(g)}function X(e){a.filter=e,u&&(u.querySelectorAll(".chip").forEach(t=>{let n=t;n.classList.toggle("active",n.dataset.filter===e)}),k())}function _(e){a.open=e??!a.open,g?.classList.toggle("open",a.open)}function G(e){if(!e)return"";let t=Date.now()-e;return t<1e4?"just now":t<6e4?`${Math.floor(t/1e3)}s ago`:t<36e5?`${Math.floor(t/6e4)}m ago`:`${Math.floor(t/36e5)}h ago`}function V(e){return e.rationale?.startsWith("[proactive:capture_start]")?"Opener":e.rationale?.startsWith("[proactive:rep_silence]")?"Next question":e.rationale?.startsWith("[proactive:stage_transition]")?"Stage cue":e.type==="ask_next"?"Ask next":e.type==="answer"?"Answer":e.type==="risk"?"Risk":e.type==="coach"?"Coach":"Suggestion"}function K(e){return!!(e.answerText&&e.answerText.trim().length>0||e.followupText&&e.followupText.trim().length>0)}function k(){if(!f||!h)return;f.replaceChildren();let e=a.history.filter(K),t=e.filter(n=>a.filter==="all"?!0:n.type===a.filter);if(t.length===0){let n=document.createElement("div");n.className="empty",n.textContent=e.length===0?"No suggestions yet. Start speaking to trigger the coach.":"No suggestions match this filter.",f.appendChild(n)}else for(let n of t){let r=document.createElement("div");r.className="card";let s=document.createElement("div");s.className="meta";let p=document.createElement("span");p.textContent=V(n);let o=document.createElement("span");if(o.className="ago",o.textContent=G(n.receivedAt),s.appendChild(p),s.appendChild(o),r.appendChild(s),n.answerText){let l=document.createElement("div");l.className="answer",l.textContent=n.answerText,r.appendChild(l)}if(n.followupText){let l=document.createElement("div");l.className="followup",l.textContent=`\u2192 ${n.followupText}`,r.appendChild(l)}f.appendChild(r)}h.textContent=String(a.history.length)}async function Q(){if(a.meetingId)try{await chrome.storage.local.set({[A(a.meetingId)]:a.history.slice(0,F)})}catch(e){C.warn("[athena-panel] persist failed",e)}}async function Z(e){a.meetingId=e;try{let n=(await chrome.storage.local.get(A(e)))[A(e)];a.history=Array.isArray(n)?n:[]}catch(t){C.warn("[athena-panel] hydrate failed",t),a.history=[]}M(),k()}function R(e){M();let t={...e,receivedAt:Date.now()};a.history=[t,...a.history].slice(0,F),k(),Q()}function D(e){a.meetingId===e&&u||Z(e)}var T=null;function I(){let e=E.exec(window.location.href);if(!e||!e[1])return;let t=e[1],n=document.title?.replace(/^Meet\s*[-–]\s*/i,"").trim()||null;if(T===t)return;T=t,D(t);let r={type:"meet.detected",tabId:-1,meetingUrl:`https://meet.google.com/${t}`,meetingId:t,title:n,detectedAt:new Date().toISOString()};chrome.runtime.sendMessage(r)}I();var N=document.querySelector("title");N&&new MutationObserver(()=>I()).observe(N,{childList:!0,subtree:!0});var P=window.location.href;setInterval(()=>{window.location.href!==P&&(P=window.location.href,I())},1e3);window.addEventListener("beforeunload",()=>{let t=E.exec(window.location.href)?.[1]??T;if(!t)return;let n={type:"meet.left",tabId:-1,meetingId:t};chrome.runtime.sendMessage(n)});var H="athena-overlay-root",O="athena-overlay-style",$=2,z=15e3,U={answer:"#34D399",ask_next:"#60A5FA",coach:"#FBBF24",risk:"#F87171"},ee={answer:"Answer",ask_next:"Ask next",coach:"Coach",risk:"Risk"};function te(){if(document.getElementById(O))return;let e=document.createElement("style");e.id=O,e.textContent=`
    @keyframes athena-card-in {
      from { opacity: 0; transform: translateY(-6px); }
      to   { opacity: 1; transform: translateY(0); }
    }
    @keyframes athena-card-out {
      from { opacity: 1; transform: scale(1); }
      to   { opacity: 0; transform: scale(0.98); }
    }
    @keyframes athena-progress {
      from { transform: scaleX(1); }
      to   { transform: scaleX(0); }
    }
    @media (prefers-reduced-motion: reduce) {
      .athena-card { animation: athena-card-in 1ms linear !important; }
      .athena-card.athena-exiting { animation: athena-card-out 1ms linear !important; }
      .athena-progress { animation: none !important; transform: scaleX(0) !important; }
    }
  `,document.documentElement.appendChild(e)}function q(){let e=document.getElementById(H);return e||(te(),e=document.createElement("div"),e.id=H,e.setAttribute("role","status"),e.setAttribute("aria-live","polite"),e.style.cssText=["position:fixed","top:24px","left:50%","transform:translateX(-50%)","max-height:15vh","max-width:min(560px,60vw)","width:max-content","z-index:2147483646","display:flex","flex-direction:column-reverse","gap:10px","pointer-events:none","font-family:Inter,-apple-system,system-ui,sans-serif"].join(";"),document.documentElement.appendChild(e),e)}function ne(e){let t=q();for(;t.children.length>=$;)t.lastElementChild?.remove();let n=document.createElement("div");n.className="athena-card",n.style.cssText=["background:rgba(17,24,39,0.42)","backdrop-filter:blur(28px) saturate(160%)","-webkit-backdrop-filter:blur(28px) saturate(160%)","color:#F8FAFC","border:1px solid rgba(255,255,255,0.14)","border-radius:16px","padding:14px 16px","box-shadow:0 12px 40px rgba(0,0,0,0.28),inset 0 1px 0 rgba(255,255,255,0.08)","font-size:14px","line-height:1.45","pointer-events:none","animation:athena-card-in 240ms cubic-bezier(0.22,1,0.36,1)","position:relative","overflow:hidden","text-shadow:0 1px 2px rgba(0,0,0,0.4)"].join(";");let r=e.type??"answer",s=U[r]??U.answer,p=ee[r]??"Suggestion",o=document.createElement("div");o.style.cssText="display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:11px;color:rgba(248,250,252,0.72);font-weight:600;letter-spacing:0.4px";let l=document.createElement("span");if(l.textContent=p.toUpperCase(),l.style.cssText=`color:${s};text-transform:uppercase;letter-spacing:0.6px`,o.appendChild(l),typeof e.confidenceScore=="number"){let c=document.createElement("span");c.textContent=`\xB7 ${e.confidenceScore.toFixed(2)}`,c.style.cssText="opacity:0.65;font-weight:500",o.appendChild(c)}let v=document.createElement("span");v.style.cssText="flex:1",o.appendChild(v);let x=!1,m=()=>{x||(x=!0,n.classList.add("athena-exiting"),n.style.animation="athena-card-out 200ms cubic-bezier(0.4,0,0.2,1) forwards",setTimeout(()=>n.remove(),220))},i=document.createElement("button");if(i.type="button",i.setAttribute("aria-label","Dismiss suggestion"),i.textContent="\u2715",i.style.cssText="pointer-events:auto;cursor:pointer;background:transparent;border:none;color:rgba(248,250,252,0.78);font-size:13px;padding:2px 6px;border-radius:6px;line-height:1;transition:background 150ms ease",i.addEventListener("mouseenter",()=>{i.style.background="rgba(255,255,255,0.10)"}),i.addEventListener("mouseleave",()=>{i.style.background="transparent"}),i.addEventListener("click",m),o.appendChild(i),n.appendChild(o),e.answerText){let c=document.createElement("div");c.textContent=e.answerText,c.style.cssText="color:#F8FAFC;font-weight:500;margin-bottom:6px",n.appendChild(c)}if(e.followupText){let c=document.createElement("div");c.textContent=`\u2192 Ask next: ${e.followupText}`,c.style.cssText="color:rgba(248,250,252,0.78);font-style:italic;font-size:12px;margin-bottom:4px",n.appendChild(c)}if(e.sources&&e.sources.length>0){let c=document.createElement("div");c.style.cssText="margin-top:6px;font-size:10px;color:rgba(248,250,252,0.55)",c.textContent=`Source \xB7 ${e.sources.map(j=>j.documentName??"?").join(", ")}`,n.appendChild(c)}let d=document.createElement("div");d.className="athena-progress",d.style.cssText=["position:absolute","left:0","right:0","bottom:0","height:2px",`background:${s}`,"opacity:0.7","transform-origin:left center",`animation:athena-progress ${z}ms linear forwards`].join(";"),n.appendChild(d),t.appendChild(n),setTimeout(m,z)}var w=null,b=null,y=null;function re(e,t){let n=q();if(!w){for(;n.children.length>=$;)n.lastElementChild?.remove();let r=document.createElement("div");r.className="athena-card athena-card-streaming",r.style.cssText=["background:rgba(17,24,39,0.42)","backdrop-filter:blur(28px) saturate(160%)","-webkit-backdrop-filter:blur(28px) saturate(160%)","color:#F8FAFC","border:1px solid rgba(255,255,255,0.14)","border-radius:16px","padding:14px 16px","box-shadow:0 12px 40px rgba(0,0,0,0.28),inset 0 1px 0 rgba(255,255,255,0.08)","font-size:14px","line-height:1.45","pointer-events:none","animation:athena-card-in 240ms cubic-bezier(0.22,1,0.36,1)","position:relative","overflow:hidden","text-shadow:0 1px 2px rgba(0,0,0,0.4)"].join(";");let s=document.createElement("div");s.style.cssText="display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:11px;color:rgba(248,250,252,0.72);font-weight:600;letter-spacing:0.4px";let p=document.createElement("span");p.textContent="COACH",p.style.cssText="color:#34D399;text-transform:uppercase;letter-spacing:0.6px",s.appendChild(p);let o=document.createElement("span");o.textContent="typing\u2026",o.style.cssText="opacity:0.55;font-weight:500;font-style:italic",s.appendChild(o),r.appendChild(s),b=document.createElement("div"),b.style.cssText="color:#F8FAFC;font-weight:500;margin-bottom:6px;min-height:1.45em",r.appendChild(b),y=document.createElement("div"),y.style.cssText="color:rgba(248,250,252,0.78);font-style:italic;font-size:12px;margin-bottom:4px",r.appendChild(y),n.appendChild(r),w=r}b&&(b.textContent=e??""),y&&t&&(y.textContent=`\u2192 Ask next: ${t}`)}function oe(){w&&(w.remove(),w=null,b=null,y=null)}chrome.runtime.onMessage.addListener(e=>{if(e?.type!=="panel.toggle"){if(e?.type==="overlay.suggestion.streaming"){try{re(e.answerText??null,e.followupText??null)}catch(t){console.warn("[rocket-content] streaming render failed",t)}return}if(!(e?.type!=="overlay.suggestion"||!e.suggestion))try{oe(),R(e.suggestion);let t=!!(e.suggestion.answerText||e.suggestion.followupText);console.debug("[rocket-content] overlay.suggestion",{type:e.suggestion.type,hasAnswer:!!e.suggestion.answerText,hasFollowup:!!e.suggestion.followupText,speakable:t}),t&&ne(e.suggestion)}catch(t){console.warn("[rocket-content] overlay render failed",t)}}});var S="athena-recording-pill";function ae(){let e=document.getElementById(S);if(e)return;e=document.createElement("div"),e.id=S,e.style.cssText=["position:fixed","top:24px","right:24px","z-index:2147483647","background:rgba(17,24,39,0.42)","backdrop-filter:blur(28px) saturate(160%)","-webkit-backdrop-filter:blur(28px) saturate(160%)","color:#F8FAFC","border:1px solid rgba(255,255,255,0.14)","padding:6px 12px 6px 10px","border-radius:999px","font:600 11px Inter,-apple-system,system-ui,sans-serif","letter-spacing:0.4px","box-shadow:0 12px 40px rgba(0,0,0,0.28),inset 0 1px 0 rgba(255,255,255,0.08)","text-shadow:0 1px 2px rgba(0,0,0,0.4)","pointer-events:none","display:flex","align-items:center","gap:8px"].join(";");let t=document.createElement("span");if(t.style.cssText="width:8px;height:8px;border-radius:999px;background:#F87171;box-shadow:0 0 8px rgba(248,113,113,0.7);animation:athena-pulse 1.5s infinite",e.appendChild(t),e.appendChild(document.createTextNode("Rocket recording")),document.documentElement.appendChild(e),!document.getElementById("athena-pill-style")){let n=document.createElement("style");n.id="athena-pill-style",n.textContent="@keyframes athena-pulse { 0%,100% { opacity:1 } 50% { opacity:0.4 } }",document.documentElement.appendChild(n)}}function ie(){document.getElementById(S)?.remove()}function B(){chrome.storage.local.get(["capture"]).then(e=>{let t=e.capture??null;t&&!t.closed?ae():ie()})}B();chrome.storage.onChanged.addListener((e,t)=>{t!=="local"||!e.capture||B()});
